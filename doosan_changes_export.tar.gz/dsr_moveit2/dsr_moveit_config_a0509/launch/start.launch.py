#
#  dsr_bringup2
#  Author: Minsoo Song (minsoo.song@doosan.com)
#
#  Copyright (c) 2024 Doosan Robotics
#  Use of this source code is governed by the BSD, see LICENSE
#

import os

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    GroupAction,
    OpaqueFunction,
    RegisterEventHandler,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.substitutions import (
    Command,
    FindExecutable,
    LaunchConfiguration,
    PathJoinSubstitution,
    PythonExpression,
)

from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory

from moveit_configs_utils import MoveItConfigsBuilder
from dsr_bringup2.utils import read_update_rate


def _is_mode(mode_name: str):
    return IfCondition(
        PythonExpression([
            "'", LaunchConfiguration("mode"), "' == '", mode_name, "'"
        ])
    )


def _as_bool(value: str) -> bool:
    return str(value).lower() in ["true", "1", "yes", "y", "on"]


def move_group_and_rviz_function(context):
    model_value = LaunchConfiguration("model").perform(context)
    joint_states_topic = (
        LaunchConfiguration("joint_states_topic").perform(context)
        or "/joint_states"
    )
    gui_value = LaunchConfiguration("gui").perform(context)

    model_value_str = f"{model_value}"
    package_name_str = f"dsr_moveit_config_{model_value_str}"

    package_path_str = FindPackageShare(package_name_str).perform(context)

    print("Package name:", package_name_str)
    print("Package path:", package_path_str)
    print("MoveIt joint_states topic:", joint_states_topic)
    print("RViz gui:", gui_value)

    moveit_config = (
        MoveItConfigsBuilder(
            model_value_str,
            "robot_description",
            package_name_str,
        )
        .robot_description(file_path=f"config/{model_value_str}.urdf.xacro")
        .robot_description_semantic(file_path="config/dsr.srdf")
        .trajectory_execution(file_path="config/moveit_controllers.yaml")
        .planning_pipelines(
            pipelines=[
                "ompl",
                "chomp",
                "pilz_industrial_motion_planner",
            ],
            default_planning_pipeline="ompl",
            load_all=False,
        )
        .to_moveit_configs()
    )

    move_group_node = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        name="move_group",
        output="screen",
        remappings=[
            ("joint_states", joint_states_topic),
        ],
        parameters=[
            moveit_config.to_dict(),
        ],
    )

    actions = [move_group_node]

    if _as_bool(gui_value):
        package_share = get_package_share_directory(package_name_str)

        rviz_candidates = [
            os.path.join(package_share, "launch", "moveit.rviz"),
            os.path.join(package_share, "config", "moveit.rviz"),
        ]

        rviz_full_config = None
        for candidate in rviz_candidates:
            if os.path.exists(candidate):
                rviz_full_config = candidate
                break

        if rviz_full_config is None:
            rviz_full_config = rviz_candidates[0]
            print("[WARN] moveit.rviz not found. Trying default path:", rviz_full_config)
        else:
            print("RViz config:", rviz_full_config)

        rviz_node = Node(
            package="rviz2",
            executable="rviz2",
            name="rviz2",
            output="screen",
            arguments=[
                "-d",
                rviz_full_config,
            ],
            parameters=[
                moveit_config.robot_description,
                moveit_config.robot_description_semantic,
                moveit_config.planning_pipelines,
                moveit_config.robot_description_kinematics,
                moveit_config.joint_limits,
            ],
        )

        actions.append(rviz_node)

    return actions


def create_controller_sequence(start_delay: float):
    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        namespace=LaunchConfiguration("name"),
        executable="spawner",
        name="spawner_joint_state_broadcaster",
        arguments=[
            "joint_state_broadcaster",
            "--controller-manager",
            "/controller_manager",
            "--controller-manager-timeout",
            "120",
        ],
        output="screen",
    )

    robot_controller_spawner = Node(
        package="controller_manager",
        namespace=LaunchConfiguration("name"),
        executable="spawner",
        name="spawner_dsr_controller2",
        arguments=[
            "dsr_controller2",
            "--controller-manager",
            "/controller_manager",
            "--controller-manager-timeout",
            "120",
        ],
        output="screen",
    )

    dsr_moveit_controller_spawner = Node(
        package="controller_manager",
        namespace=LaunchConfiguration("name"),
        executable="spawner",
        name="spawner_dsr_moveit_controller",
        arguments=[
            "dsr_moveit_controller",
            "--controller-manager",
            "/controller_manager",
            "--controller-manager-timeout",
            "120",
        ],
        output="screen",
    )

    start_joint_state_broadcaster = TimerAction(
        period=start_delay,
        actions=[
            joint_state_broadcaster_spawner,
        ],
    )

    start_robot_controller_after_jsb = RegisterEventHandler(
        OnProcessExit(
            target_action=joint_state_broadcaster_spawner,
            on_exit=[
                robot_controller_spawner,
            ],
        )
    )

    start_moveit_controller_after_robot_controller = RegisterEventHandler(
        OnProcessExit(
            target_action=robot_controller_spawner,
            on_exit=[
                dsr_moveit_controller_spawner,
            ],
        )
    )

    return [
        start_joint_state_broadcaster,
        start_robot_controller_after_jsb,
        start_moveit_controller_after_robot_controller,
    ]


def generate_launch_description():
    arguments = [
        DeclareLaunchArgument(
            "name",
            default_value="",
            description="NAME_SPACE",
        ),
        DeclareLaunchArgument(
            "host",
            default_value="127.0.0.1",
            description="ROBOT_IP",
        ),
        DeclareLaunchArgument(
            "port",
            default_value="12345",
            description="ROBOT_PORT",
        ),
        DeclareLaunchArgument(
            "mode",
            default_value="virtual",
            description="OPERATION MODE: virtual | real",
        ),
        DeclareLaunchArgument(
            "model",
            default_value="a0509",
            description="ROBOT_MODEL",
        ),
        DeclareLaunchArgument(
            "color",
            default_value="white",
            description="ROBOT_COLOR",
        ),
        DeclareLaunchArgument(
            "gui",
            default_value="false",
            description="Start RViz2",
        ),
        DeclareLaunchArgument(
            "gz",
            default_value="false",
            description="USE GAZEBO SIM",
        ),
        DeclareLaunchArgument(
            "rt_host",
            default_value="192.168.137.50",
            description="ROBOT_RT_IP",
        ),
        DeclareLaunchArgument(
            "joint_states_topic",
            default_value="/joint_states",
            description="Topic for joint_states. Example: /joint_states or /moveit/joint_states",
        ),
    ]

    update_rate = str(read_update_rate())

    robot_description_content = Command(
        [
            PathJoinSubstitution([FindExecutable(name="xacro")]),
            " ",
            PathJoinSubstitution([
                FindPackageShare("dsr_description2"),
                "xacro",
                LaunchConfiguration("model"),
            ]),
            ".urdf.xacro",
            " name:=",
            LaunchConfiguration("name"),
            " host:=",
            LaunchConfiguration("host"),
            " rt_host:=",
            LaunchConfiguration("rt_host"),
            " port:=",
            LaunchConfiguration("port"),
            " mode:=",
            LaunchConfiguration("mode"),
            " model:=",
            LaunchConfiguration("model"),
            " color:=",
            LaunchConfiguration("color"),
            " update_rate:=",
            update_rate,
        ]
    )

    robot_description = {
        "robot_description": robot_description_content,
    }

    robot_controllers = [
        PathJoinSubstitution([
            FindPackageShare("dsr_controller2"),
            "config",
            "dsr_controller2.yaml",
        ])
    ]

    run_emulator_node = Node(
        package="dsr_bringup2",
        executable="run_emulator",
        namespace=LaunchConfiguration("name"),
        name="run_emulator",
        parameters=[
            {"name": LaunchConfiguration("name")},
            {"rate": 100},
            {"standby": 5000},
            {"command": True},
            {"host": LaunchConfiguration("host")},
            {"port": LaunchConfiguration("port")},
            {"mode": LaunchConfiguration("mode")},
            {"model": LaunchConfiguration("model")},
            {"gripper": "none"},
            {"mobile": "none"},
            {"rt_host": LaunchConfiguration("rt_host")},
        ],
        output="screen",
    )

    control_node = Node(
        package="controller_manager",
        executable="ros2_control_node",
        namespace=LaunchConfiguration("name"),
        parameters=[
            robot_description,
            robot_controllers,
        ],
        arguments=[
            "--ros-args",
            "--log-level",
            "controller_manager:=error",
        ],
        output="both",
    )

    robot_state_pub_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        namespace=LaunchConfiguration("name"),
        name="robot_state_publisher",
        output="both",
        remappings=[
            ("joint_states", LaunchConfiguration("joint_states_topic")),
        ],
        parameters=[
            robot_description,
        ],
    )

    # -----------------------------
    # Virtual mode group
    # -----------------------------
    virtual_group = GroupAction(
        condition=_is_mode("virtual"),
        actions=[
            run_emulator_node,

            # Virtual에서는 emulator 기동 후 controller spawner를 조금 늦게 시작
            *create_controller_sequence(start_delay=5.0),

            # MoveIt + RViz
            TimerAction(
                period=10.0,
                actions=[
                    OpaqueFunction(function=move_group_and_rviz_function),
                ],
            ),
        ],
    )

    # -----------------------------
    # Real mode group
    # -----------------------------
    real_group = GroupAction(
        condition=_is_mode("real"),
        actions=[
            # Real에서는 run_emulator 실행 금지
            # 실제 로봇 연결이 STATE_STANDBY까지 가는 시간을 고려해 spawner를 조금 더 늦게 시작
            *create_controller_sequence(start_delay=8.0),

            # MoveIt + RViz
            TimerAction(
                period=15.0,
                actions=[
                    OpaqueFunction(function=move_group_and_rviz_function),
                ],
            ),
        ],
    )

    nodes = [
        robot_state_pub_node,
        control_node,

        virtual_group,
        real_group,
    ]

    return LaunchDescription(arguments + nodes)